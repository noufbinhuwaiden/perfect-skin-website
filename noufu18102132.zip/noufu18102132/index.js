const discount = document.getElementById("discount-modal");
setTimeout(function() {
    discount.style.display = "block"
}, 3000)

const cross = document.getElementById("cross-icon");
cross.addEventListener('click', function() {
    discount.style.display = "none"
})